package com.mukeapps.microservices.OauthSocialClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthSocialClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
