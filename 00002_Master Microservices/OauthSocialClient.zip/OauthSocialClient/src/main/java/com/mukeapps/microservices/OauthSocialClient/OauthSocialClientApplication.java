package com.mukeapps.microservices.OauthSocialClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthSocialClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthSocialClientApplication.class, args);
	}

}
