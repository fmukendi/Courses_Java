package com.mukeapps.microservices.OauthSocialLogIn000;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthSocialLogIn000ApplicationTests {

	@Test
	void contextLoads() {
	}

}
